// app/home/page.tsx

import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { createServerClient } from "@supabase/ssr";

export default async function HomeResolverPage() {
  const cookieStore = await cookies();

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
      },
    }
  );

  // 1) Must be authenticated
  const {
    data: { user: authUser },
  } = await supabase.auth.getUser();

  if (!authUser) {
    redirect("/login");
  }

  // 2) Resolve app-level user
  const { data: appUser } = await supabase
    .from("users")
    .select("id")
    .eq("auth_id", authUser.id)
    .maybeSingle<{ id: string }>();

  if (!appUser) {
    // Auth exists but app profile not created yet
    redirect("/account");
  }

  // 3) Check for athlete record
  const { data: athlete } = await supabase
    .from("athletes")
    .select("id, is_claimed")
    .eq("user_id", appUser.id)
    .maybeSingle<{ id: string; is_claimed: boolean }>();

  if (athlete) {
    // Athlete path
    // Claim completion must be handled via modal/UX on the athlete page to avoid redirect loops.
    // Send athletes to the single athlete surface.
    redirect("/athletes/me");
  }

  // 4) Otherwise treat as coach/staff for now
  redirect("/dashboard");
}
