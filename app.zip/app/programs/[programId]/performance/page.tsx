// app/(app)/programs/[programId]/performance/page.tsx
import PerformanceMapPage from "@/components/performance/map/PerformanceMapPage";

export default function Page() {
  return <PerformanceMapPage />;
}