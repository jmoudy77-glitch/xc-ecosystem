// page.tsx
import StaffPageClient from '@/components/staff/StaffPageClient';

export default function Page() {
  return <StaffPageClient />;
}
