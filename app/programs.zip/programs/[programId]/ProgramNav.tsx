"use client";

import Link from "next/link";
import { useParams, usePathname } from "next/navigation";

type NavItem = {
  label: string;
  href: (programId: string) => string;
};

const NAV_ITEMS: NavItem[] = [
  {
    label: "Dashboard",
    href: (programId) => `/programs/${programId}/dashboard`,
  },
  {
    label: "Teams",
    href: (programId) => `/programs/${programId}/teams`,
  },
  {
    label: "Recruiting",
    href: (programId) => `/programs/${programId}/recruiting`,
  },
  {
    label: "Training",
    href: (programId) => `/programs/${programId}/training`,
  },
  {
    label: "Communications",
    href: (programId) => `/programs/${programId}/communications`,
  },
  {
    label: "Staff",
    href: (programId) => `/programs/${programId}/staff`,
  },
];

export function ProgramNav() {
  const params = useParams<{ programId: string }>();
  const programId = params?.programId;
  const pathname = usePathname();

  if (!programId) return null;

  return (
    <div className="flex flex-col gap-4 text-[11px]">
      <nav className="space-y-1">
        {NAV_ITEMS.map((item) => {
          const href = item.href(programId);
          const isActive =
            pathname === href ||
            (href !== `/programs/${programId}` && pathname.startsWith(href));

          return (
            <Link
              key={item.label}
              href={href}
              className={[
                "flex items-center justify-between rounded-lg border border-subtle px-3 py-2 transition-colors",
                isActive
                  ? "bg-brand"
                  : "bg-brand-soft hover:bg-brand-soft/80 text-muted",
              ].join(" ")}
            >
              <span>{item.label}</span>
              <span className="text-[9px] opacity-60">→</span>
            </Link>
          );
        })}
      </nav>

      {/* Account / settings as secondary nav items */}
      <div className="border-t border-subtle pt-2">
        <div className="space-y-1">
          <Link
            href="/account"
            className="flex items-center justify-between rounded-lg border border-subtle bg-brand-soft px-3 py-2 transition-colors text-muted hover:bg-brand-soft/80"
          >
            <span>Account</span>
            <span className="text-[9px] opacity-60">↗</span>
          </Link>

          <Link
            href={`/programs/${programId}/settings/branding`}
            className="flex items-center justify-between rounded-lg border border-subtle bg-brand-soft px-3 py-2 transition-colors text-muted hover:bg-brand-soft/80"
          >
            <span>Branding</span>
            <span className="text-[9px] opacity-60">🎨</span>
          </Link>
        </div>
      </div>
    </div>
  );
}