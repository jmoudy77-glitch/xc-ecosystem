# Multi-Tenant Architecture

Describe how multi-tenancy is implemented:

- Organizations, programs, teams, seasons
- Program-level isolation for sensitive data
- Global athlete identity across multiple programs
- Public vs program-private vs athlete-private data
