# Navigation Architecture

Describe the signed-in navigation for different roles:

- College coach / HS coach
- Program admin vs staff vs athlete
- Core sections:
  - Dashboard
  - Roster & Seasons
  - Recruiting
  - Team Ops (practice, S&C, comms)
  - Results & Meets
  - Settings & Billing
