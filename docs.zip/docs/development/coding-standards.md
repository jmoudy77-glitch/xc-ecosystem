# Coding Standards

Define standards for:

- TypeScript and React
- Folder and file naming
- Component patterns (server vs client)
- Error handling
