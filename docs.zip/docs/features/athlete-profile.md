# Athlete Profile

Describe the unified athlete profile:

- Tabs: Overview, Performance, Academics, Evaluations, Accolades, Recruiting, Medical, S&C
- Media (avatar, highlight reels, photos)
- How profile data flows from results, training, and recruiting modules
