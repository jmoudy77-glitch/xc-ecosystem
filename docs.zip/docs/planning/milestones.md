# Milestones

Define major phases and key checkpoints.

Example:
- Phase 1: Core roster + athlete profiles
- Phase 2: Recruiting pipeline MVP
- Phase 3: Team Ops tools
- Phase 4: Results + Meet Manager
