# Project Scope

Full definition of boundaries, target users, core deliverables.