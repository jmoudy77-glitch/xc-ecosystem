# Requirements

Capture high-level functional and non-functional requirements.

Group by domain (Roster, Recruiting, Team Ops, Results, AI, Billing, etc.).
