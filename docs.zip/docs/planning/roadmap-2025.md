# 2025 Roadmap

Lay out planned work across quarters, aligned with milestones and capacity.
