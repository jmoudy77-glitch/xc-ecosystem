# Results & Performance Overview

Describe why results sit at the core of the ecosystem and how they:

- Populate athlete stats
- Power recruiting and AI
- Feed back into team planning and meet operations
