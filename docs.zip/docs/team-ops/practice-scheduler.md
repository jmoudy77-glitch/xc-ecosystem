# Practice Scheduler

Describe the 3-layer model:

1. Training events (system-standard and program-specific)
2. Reusable workouts (program-owned)
3. Scheduled practice sessions (team-based, assignable to groups and individuals)

Include weather integration and notes.
