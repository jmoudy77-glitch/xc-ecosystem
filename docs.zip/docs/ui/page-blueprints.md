# Page Blueprints

Provide blueprints for key pages:

- Dashboard
- Team Management
- Recruiting Board
- Athlete Profile
- Practice Scheduler
- Meet Manager
