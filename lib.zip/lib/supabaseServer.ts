// lib/supabaseServer.ts
//
// Bulletproof server-side Supabase client for Next.js App Router.
// Does NOT use cookies().get or cookies().set.
// Uses the safe request/response binding recommended by Supabase.

import { NextRequest, NextResponse } from "next/server";
import { createServerClient } from "@supabase/ssr";

export function supabaseServer(req: NextRequest) {
  // We create a mutable response that Supabase can write cookies into
  const res = NextResponse.next();

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        // Supabase reads and writes through req/res
        get: (name) => req.cookies.get(name)?.value,
        set: (name, value, options) => res.cookies.set(name, value, options),
        remove: (name, options) =>
          res.cookies.set(name, "", { ...options, maxAge: 0 }),
      },
    }
  );

  return { supabase, res };
}