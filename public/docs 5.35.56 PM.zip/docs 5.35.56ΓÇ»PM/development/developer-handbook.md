# Developer Handbook

Describe how to set up and work on the project:

- Prerequisites
- Cloning and installing
- Running dev environment
- Environment variables and secrets
