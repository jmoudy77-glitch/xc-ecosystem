# Inquiries & Invites

Document:

- Athlete inquiry forms (`athlete_inquiries`)
- Program-to-athlete invites (`athlete_invites`)
- How these connect to recruiting profiles and onboarding flows
