# Recruiting Pipeline

Describe the recruiting engine:

- Pipeline stages (discovered, evaluating, pursuing, offer, committed, signed, inactive)
- Scout score, fit score, commit probability
- Recruit boards per program, per event group, per grad year
- Integration with roster forecasting and scholarship budgets
