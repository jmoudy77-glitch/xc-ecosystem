# Transfer Portal

Describe the transfer portal feature:

- `transfer_portal_entries` usage
- Visibility rules for programs
- Interaction with recruiting pipeline and athlete profiles
