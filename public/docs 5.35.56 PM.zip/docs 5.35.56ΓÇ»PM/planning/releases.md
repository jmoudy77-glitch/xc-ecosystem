# Releases

Outline releases and tags:

- Internal alpha
- Limited beta
- Public beta
- GA

Document what each release includes at a high level.
