# API Style Guide

Document API design rules:

- REST/HTTP conventions
- Request/response patterns
- Error codes and messages
