# Decision Log.Md

Append-only log.
