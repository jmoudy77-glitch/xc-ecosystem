# Roster System

Describe the Season Roster Builder and Team Management Hub:

- Team seasons and active rosters
- Roster states (active, redshirt, medical, etc.)
- Scholarship display and budgets
- Event groups and roster roles
- Integration with recruiting and scenarios
