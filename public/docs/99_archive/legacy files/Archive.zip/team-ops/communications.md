# Communications

Describe communication tools:

- Channels: team, event group, individual athlete, staff-only
- Message history and logging
- Notification concepts
