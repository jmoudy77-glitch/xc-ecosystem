# Meet Manager

Describe the meet manager concept:

- Meet creation and configuration
- Events, sessions, and timelines
- Future integration with entries, seeding, heats, flights, and live results
