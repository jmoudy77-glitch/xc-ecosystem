# Team Operations Overview

Team Ops = daily operating system for coaches:

- Practice planning
- Strength & conditioning
- Stats and training logs
- Internal communications
- Evaluations
- Meet operations (via Meet Manager)
