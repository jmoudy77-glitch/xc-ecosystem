# Academic Risk Index

Describe academic data inputs and risk scoring.
