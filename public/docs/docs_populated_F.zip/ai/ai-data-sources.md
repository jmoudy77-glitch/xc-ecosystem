# AI Data Sources

List all schema tables and derived metrics used as AI inputs.
