# Commit Probability

Define inputs, model concept, and how probabilities surface in the UI.
