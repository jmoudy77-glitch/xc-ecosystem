# Event Fit Score

Describe how athletes are matched to event groups and events.
