# Pipeline Projection

Describe how the system projects class and roster outcomes.
