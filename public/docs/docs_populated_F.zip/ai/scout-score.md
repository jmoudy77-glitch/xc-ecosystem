# Scout Score

Define inputs, algorithm concept, and output usage.
