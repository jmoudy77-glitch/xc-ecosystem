# Data Flow

Describe key end-to-end flows, for example:

- Athlete lifecycle: discovery → recruiting pipeline → roster → alumni
- Results lifecycle: meet event → performance → stats → AI scoring
- Practice & training lifecycle: planned sessions → athlete logs → training history → AI suggestions
