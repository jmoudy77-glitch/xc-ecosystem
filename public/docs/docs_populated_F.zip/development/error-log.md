# Error Log.Md

Append-only log.
