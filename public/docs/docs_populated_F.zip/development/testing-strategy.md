# Testing Strategy

Outline:

- What to unit test vs integration test
- Tools and frameworks to use
- Testing priorities by subsystem
