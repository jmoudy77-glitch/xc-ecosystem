# Billing & Plans

Document billing model:

- Program vs athlete subscriptions
- Plan codes and what they unlock
- Stripe customers, subscriptions, and webhooks
