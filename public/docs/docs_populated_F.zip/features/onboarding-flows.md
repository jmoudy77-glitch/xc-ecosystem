# Onboarding Flows

Describe onboarding for:

- High school coaches
- College coaches
- Athletes

Cover invites, claim flows, and initial roster/recruit seeding.
