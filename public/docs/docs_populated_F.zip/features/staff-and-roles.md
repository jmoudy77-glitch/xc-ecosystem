# Staff & Roles

Describe staff management:

- Program members and roles
- Inviting staff
- What each role sees in the UI
