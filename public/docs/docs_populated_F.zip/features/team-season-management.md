# Team & Season Management

Describe:

- Program teams and levels
- Creating and managing seasons
- Marking current seasons and locking rosters
- Scholarship budgets per season
