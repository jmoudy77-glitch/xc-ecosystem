# Project Scope

Define the boundaries of the XC Ecosystem:

- Target users (HS coaches, college coaches, athletes)
- In-scope domains and features
- Out-of-scope areas for this product
