# Event Codes

Define `event_code` strategy:

- How codes map to sports and events
- Versioning and extension for new disciplines
