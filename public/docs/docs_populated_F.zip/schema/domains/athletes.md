# Athletes Schema

Document tables: athletes, athlete_media, athlete_performances, athlete_scores, athlete_training_sessions, athlete_scholarship_history.
