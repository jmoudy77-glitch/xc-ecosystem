# Session Snapshots

This folder contains dated session snapshots capturing decisions, work summaries, and open questions.

Naming convention: `YYYY-MM-DD-snapshot.md`.
