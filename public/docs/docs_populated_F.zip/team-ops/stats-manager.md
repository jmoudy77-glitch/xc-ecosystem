# Stats Manager

Describe V1 stats management:

- Tracking PRs and season bests
- Workout logs and summaries
- Strength numbers and trends
- Integration with athlete profiles and AI projections
