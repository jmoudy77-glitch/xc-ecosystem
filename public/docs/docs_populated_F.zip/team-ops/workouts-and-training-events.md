# Workouts & Training Events

Define:

- `training_events`: atomic building blocks (drills, runs, gym exercises)
- `workouts`: sequences of training events, reusable across sessions
- How workouts connect to scheduled practices and athlete training sessions
