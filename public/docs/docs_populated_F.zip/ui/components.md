# UI Components

Document shared UI components:

- Buttons, cards, tables
- Roster rows and athlete cells
- Slide-out panels
