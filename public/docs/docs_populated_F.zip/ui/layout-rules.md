# Layout Rules

Document layout patterns:

- Page shells and headers
- Use of side panels and slide-outs
- Card layouts and grid rules
