# UI Workflows

User flows, interaction patterns, modal usage.